﻿using System;
namespace Books.Service.Internal.Api.Infrastructure
{
	public class APISetting
    {
        public string apikey { get; set; }
        public string bookClientUrl { get; set; }
    }
}

