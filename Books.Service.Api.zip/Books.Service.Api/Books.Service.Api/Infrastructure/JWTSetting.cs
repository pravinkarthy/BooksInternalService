﻿using System;
namespace Books.Service.Internal.Api.Infrastructure
{
	public class JWTSetting
    {
        public string securitykey { get; set; }
    }
}

